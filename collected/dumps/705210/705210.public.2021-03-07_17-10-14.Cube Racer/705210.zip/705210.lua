addappid(705210)
addappid(705211, 1, "57ca703ff0b1bd37cf7bd006f505fb6f56445a32d084b0493411bd0a10718d7c")
setManifestid(705211, "8867305674808530337", 0)
addappid(705212, 1, "0afbba644f14dc9790ac0aaeaec0d472be42d96b0461e69b5cde7ed52116c094")
setManifestid(705212, "4673345699719803518", 0)




addappid(898130) -- Cube Racer - Founders Early Support Upgrade
