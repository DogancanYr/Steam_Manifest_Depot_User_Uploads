addappid(1260320)
addappid(1260321, 1, "9623dafeee383701a837274d2547c7a5cbae7334393d64e82b4d2cdc01ef679e")
setManifestid(1260321, "9208201193947382579", 0)




addappid(2342040) -- Party Animals - Deluxe Pack
addappid(2545150) -- Party Animals - Preorder Pack
