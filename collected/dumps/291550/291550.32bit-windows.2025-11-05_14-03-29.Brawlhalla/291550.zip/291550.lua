addappid(291550)
addappid(291551, 1, "7912e24d0afdea4e76e9c8b3dfb438d294bfa7552216541f60d6638c81892d0e")
setManifestid(291551, "7659791587703578964", 0)
addappid(291552, 1, "7bc0a2d1a917e8f3c0046aa1281e248a5e40491c7af4a03e28703b734a13cc3d")
setManifestid(291552, "8726608285789078485", 0)




addappid(297630) -- Brawlhalla - Founders Pack
addappid(298640) -- Brawlhalla - Founders and Friends Pack
addappid(298641) -- Brawlhalla - Collectors Pack
addappid(387020) -- Brawlhalla - All Legends (Current and Future)
addappid(389720) -- Brawlhalla - Valhalla Pack
addappid(462190) -- Ignore Me - All Legends Purchased
addappid(554950) -- Brawlhalla - BCX 2016 Pack
addappid(636900) -- Brawlhalla - Spring Championship 2017 Pack
addappid(682870) -- Brawlhalla - Summer Championship 2017 Pack
addappid(742720) -- Brawlhalla - BCX 2017 Pack
addappid(802910) -- Brawlhalla - Winter Championship 2018 Pack
addappid(847210) -- Brawlhalla - Spring Championship 2018 Pack
addappid(881480) -- Brawlhalla - Summer Championship 2018 Pack
addappid(941100) -- Brawlhalla - Fall Championship 2018 Pack
addappid(953450) -- Brawlhalla - BCX 2018 Pack
addappid(1180580) -- Brawlhalla - BCX 2019 Pack
addappid(1235280) -- Brawlhalla - Winter Championship 2020 Pack
addappid(1268560) -- Brawlhalla - Battle Pass Season 1
addappid(1268561) -- Brawlhalla - Spring Championship 2020 Pack
addappid(1353520) -- Brawlhalla - Summer Championship 2020 Pack
addappid(1353521) -- Brawlhalla - Battle Pass Season 2
addappid(1353522) -- Brawlhalla - BCX 2020 Pack
addappid(1382220) -- Brawlhalla - Fall Championship 2020 Pack
addappid(1492700) -- Brawlhalla - Battle Pass Season 3
addappid(1492701) -- Brawlhalla - Winter Championship 2021 Pack
addappid(1589030) -- Brawlhalla - Spring Championship 2021 Pack
addappid(1649230) -- Brawlhalla - Summer Championship 2021 Pack
addappid(1691670) -- Brawlhalla - Battle Pass Season 4
addappid(1712220) -- Brawlhalla - Autumn Championship 2021 Pack
addappid(1774370) -- Brawlhalla - BCX 2021 Pack
addappid(1837830) -- Brawlhalla - Winter Championship 2022 Pack
addappid(1844960) -- Brawlhalla - Battle Pass Season 5
addappid(1920300) -- Brawlhalla - Spring Championship 2022 Pack
addappid(2013950) -- Brawlhalla - Battle Pass Season 6
addappid(2073080) -- Brawlhalla - Summer Championship 2022 Pack
addappid(2109890) -- Brawlhalla - Autumn Championship 2022 Pack
addappid(2172170) -- Brawlhalla - BCX 2022 Pack
addappid(2261790) -- Brawlhalla - Battle Pass Season 7
addappid(2261840) -- Brawlhalla - Winter Championship 2023 Pack
addappid(2338560) -- Brawlhalla - Spring Championship 2023 Pack
addappid(2493440) -- Brawlhalla - Summer Championship Pack 2023
addappid(2517370) -- Brawlhalla - Battle Pass Season 8
addappid(2570010) -- Brawlhalla Autumn Championship Pack 2023
addappid(2632670) -- Brawlhalla - BCX 2023 Pack
addappid(2781890) -- Brawlhalla - Winter Championship 2024 Pack
addappid(2855410) -- Brawlhalla - Spring Esports 2024 Pack
addappid(2855420) -- Brawlhalla - Summer Esports 2024 Pack
addappid(2855430) -- Brawlhalla - Autumn Esports 2024 Pack
addappid(2855440) -- Brawlhalla - BCX 2024 Pack
addappid(2974360) -- Brawlhalla: Ezio Starter Pack
addappid(3392620) -- Brawlhalla - Winter Esports 2025 Pack
addappid(3392630) -- Brawlhalla - Spring Esports 2025 Pack
addappid(3392640) -- Brawlhalla - Summer Esports 2025 Pack
addappid(3392650) -- Brawlhalla - Autumn Esports 2025 Pack
addappid(3392660) -- Brawlhalla - BCX 2025 Pack
